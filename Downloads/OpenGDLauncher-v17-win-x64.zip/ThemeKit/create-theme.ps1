param([Parameter(Mandatory=$true)][string]$Source,[Parameter(Mandatory=$true)][ValidatePattern('^[A-Za-z0-9_-]{1,64}$')][string]$Name,[string]$Author='Local user')
$ErrorActionPreference='Stop'
$sourcePath=(Resolve-Path -LiteralPath $Source).Path
$output=Join-Path $PSScriptRoot $Name
if(Test-Path -LiteralPath $output){throw 'Theme already exists.'}
$paths=@('background.png','sidebar.png','header.png','flags/ru.png','flags/en.png','panel.png','card.png','logo.png','icon.png','decoration.png','hero.png','hero.wav','ribbon.png','steam-card.png','content-card.png','mod-row.png','versions/background.png','versions/cards/normal.png','versions/cards/hover.png','versions/cards/selected.png','versions/buttons/normal.png','versions/buttons/hover.png','versions/buttons/pressed.png','buttons/normal.png','buttons/hover.png','buttons/pressed.png','buttons/disabled.png','navigation/normal.png','navigation/hover.png','navigation/pressed.png','navigation/disabled.png')
New-Item -ItemType Directory -Path $output | Out-Null
foreach($relative in $paths){$sourceFile=Join-Path $sourcePath $relative;if(Test-Path -LiteralPath $sourceFile){$destination=Join-Path $output $relative;New-Item -ItemType Directory -Force -Path (Split-Path -Parent $destination) | Out-Null;Copy-Item -LiteralPath $sourceFile -Destination $destination}}
$manifest=[ordered]@{name=$Name;author=$Author;version='1.0';backgroundColor='#0B0D18';panelColor='#141628';buttonColor='#7464F5';textColor='#FFFFFF';mutedTextColor='#B8C6D9';ribbonColor='#2B1553';ribbonTextColor='#FFFFFF';versionBackgroundColor='#0A0B18';versionCardColor='#161829';versionSelectedColor='#FB5F91';fontFamily='LemonMilk';panelOpacity=1;backgroundImage='background.png';sidebarImage='sidebar.png';headerImage='header.png';panelImage='panel.png';cardImage='card.png';logoImage='logo.png';iconImage='icon.png';decorationImage='decoration.png';heroImage='hero.png';heroSound='hero.wav';heroSoundEnabled=$true;ribbonImage='ribbon.png';steamCardImage='steam-card.png';contentCardImage='content-card.png';versionBackgroundImage='versions/background.png';versionCardNormalImage='versions/cards/normal.png';versionCardHoverImage='versions/cards/hover.png';versionCardSelectedImage='versions/cards/selected.png';versionButtonNormalImage='versions/buttons/normal.png';versionButtonHoverImage='versions/buttons/hover.png';versionButtonPressedImage='versions/buttons/pressed.png';buttonNormalImage='buttons/normal.png';buttonHoverImage='buttons/hover.png';buttonPressedImage='buttons/pressed.png';buttonDisabledImage='buttons/disabled.png';navigationNormalImage='navigation/normal.png';navigationHoverImage='navigation/hover.png';navigationPressedImage='navigation/pressed.png';navigationDisabledImage='navigation/disabled.png'}
$manifest['languageRuImage']='flags/ru.png'
$manifest['languageEnImage']='flags/en.png'
$manifest['modRowImage']='mod-row.png'
$manifest['steamIndicatorColor']='#43D79B'
$manifest | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $output 'theme.json') -Encoding utf8
Compress-Archive -Path (Join-Path $output '*') -DestinationPath (Join-Path $PSScriptRoot "$Name.zip")
Write-Output (Join-Path $PSScriptRoot "$Name.zip")
